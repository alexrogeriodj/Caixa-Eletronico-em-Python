##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2019
# Primeira edição - Novembro/2010 - ISBN 978-85-7522-250-8
# Segunda edição - Junho/2014 - ISBN 978-85-7522-408-3
# Terceira edição - Janeiro/2019 - ISBN 978-85-7522-718-3
# Site: http://python.nilo.pro.br/
#
# Arquivo: listagem3\capítulo 06\06.12 - Programa 6.4 - Repetição com tamanho fixo da lista.py
# Descrição:  Programa 6.4 - Repetição com tamanho fixo da lista
##############################################################################

# Programa 6.4 - Repetição com tamanho fixo da lista
L = [1, 2, 3]
x = 0
while x < 3:
    print(L[x])
    x += 1
