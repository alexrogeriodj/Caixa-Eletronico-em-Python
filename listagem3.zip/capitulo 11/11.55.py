##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2019
# Primeira edição - Novembro/2010 - ISBN 978-85-7522-250-8
# Segunda edição - Junho/2014 - ISBN 978-85-7522-408-3
# Terceira edição - Janeiro/2019 - ISBN 978-85-7522-718-3
# Site: http://python.nilo.pro.br/
#
# Arquivo: listagem3\capítulo 11\11.55.py
# Descrição:
##############################################################################

(1, '2018-01-01', 'Confraternização Universal')
(2, '2018-04-21', 'Tiradentes')
(3, '2018-05-01', 'Dia do trabalhador')
(4, '2018-09-07', 'Independência')
(5, '2018-10-12', 'Padroeira do Brasil')
(6, '2018-11-02', 'Finados')
(7, '2018-11-15', 'Proclamação da República')
(8, '2018-12-25', 'Natal')
