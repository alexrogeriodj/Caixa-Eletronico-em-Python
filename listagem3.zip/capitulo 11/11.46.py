##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2019
# Primeira edição - Novembro/2010 - ISBN 978-85-7522-250-8
# Segunda edição - Junho/2014 - ISBN 978-85-7522-408-3
# Terceira edição - Janeiro/2019 - ISBN 978-85-7522-718-3
# Site: http://python.nilo.pro.br/
#
# Arquivo: listagem3\capítulo 11\11.46.py
# Descrição:
##############################################################################

Região Estados População  Mínima    Máxima      Média    Total (soma)
====== =======          ========= ========== ==========  ============
CO           4          2,587,267  6,434,052  3,748,298    14,993,194
N            7            488,072  7,969,655  2,426,212    16,983,485
NE           9          2,195,662 15,044,127  6,199,406    55,794,654
S            3          6,634,250 11,164,050  9,598,587    28,795,762
SE           4          3,838,363 43,663,672 21,116,145    84,464,579
Brasil:     27            488,072 43,663,672  7,445,618   201,031,674
