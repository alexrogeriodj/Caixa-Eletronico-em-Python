##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2019
# Primeira edição - Novembro/2010 - ISBN 978-85-7522-250-8
# Segunda edição - Junho/2014 - ISBN 978-85-7522-408-3
# Terceira edição - Janeiro/2019 - ISBN 978-85-7522-718-3
# Site: http://python.nilo.pro.br/
#
# Arquivo: listagem3\capítulo 11\11.59.py
# Descrição:
##############################################################################

01/01 Confraternização Universal
21/04 Tiradentes
01/05 Dia do trabalhador
07/09 Independência
12/10 Padroeira do Brasil
02/11 Finados
15/11 Proclamação da República
25/12 Natal
