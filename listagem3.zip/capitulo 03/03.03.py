##############################################################################
# Parte do livro Introdução à Programação com Python
# Autor: Nilo Ney Coutinho Menezes
# Editora Novatec (c) 2010-2019
# Primeira edição - Novembro/2010 - ISBN 978-85-7522-250-8
# Segunda edição - Junho/2014 - ISBN 978-85-7522-408-3
# Terceira edição - Janeiro/2019 - ISBN 978-85-7522-718-3
# Site: http://python.nilo.pro.br/
#
# Arquivo: listagem3\capítulo 03\03.03.py
# Descrição:
##############################################################################

1010 = 1 x 23 + 0 x 22 + 1 x 21 + 0 x 20
     = 1 x 8 + 0 x 4 + 1 x 2 + 0 x 1
     = 8 + 0 + 2 + 0
     = 10
